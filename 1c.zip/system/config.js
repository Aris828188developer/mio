//~~~~~~~~~ Setting Owner~~~~~~~~~~//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["601129601577"] 
global.namabot = 'TREDICK INVICTUS ⚡'
//~~~~~~~~~ Setting ~~~~~~~~~~//
global.namach = "Informasi Bot & Website 2025"
global.link = ""
global.idch = ""
global.imgthumb = "https://img1.pixhost.to/images/6961/618459247_imgtmp.jpg"
global.vidthumb = "https://img1.pixhost.to/images/6961/618459247_imgtmp.jpg"
//~~~~~~~~~ Setting Mess ~~~~~~~~~~//
global.mess = { 
owner: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖮𝗐𝗇𝖾𝗋',
premium: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖯𝗋𝖾𝗆𝗂𝗎𝗆',
succes: '𝖲𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅'
//~~~~~~~~~ End ~~~~~~~~~~//
}