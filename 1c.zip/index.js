require('./system/config');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidDecode, proto } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk')
const readline = require("readline")
const { smsg, fetchJson, await, sleep } = require('./system/lib/myfunction');
//======================
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const usePairingCode = true
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, resolve)
})};
const manualPassword = 'TREDICK';
//======================
async function StartZenn() {
const { state, saveCreds } = await useMultiFileAuthState('./session')
const rikz = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: [ "Ubuntu", "Chrome", "20.0.04" ]
});
//======================
if (usePairingCode && !rikz.authState.creds.registered) {
const inputPassword = await question(chalk.red.bold('Masukkan Password:\n'));
if (inputPassword !== manualPassword) {
console.log(chalk.red('Password salah! Sistem akan dimatikan'));
            process.exit(); // Matikan konsol
        }
console.log(chalk.cyan("-[ 🔗 Time To Pairing! ]"));
const phoneNumber = await question(chalk.green("-📞 Enter Your Number Phone::\n"));
const code = await rikz.requestPairingCode(phoneNumber.trim(), "INVICTUS");
console.log(chalk.blue(`-✅ Pairing Code: `) + chalk.magenta.bold(code));
}
rikz.public = global.publik
//======================
rikz.ev.on("connection.update", async (update) => {
const { connection, lastDisconnect } = update;
if (connection === "close") {
const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
const reconnect = () => StartZenn();
const reasons = {
[DisconnectReason.badSession]: "Bad Session, hapus session dan scan ulang!",
[DisconnectReason.connectionClosed]: "Koneksi tertutup, mencoba menghubungkan ulang...",
[DisconnectReason.connectionLost]: "Koneksi terputus dari server, menghubungkan ulang...",
[DisconnectReason.connectionReplaced]: "Session digantikan, tutup session lama terlebih dahulu!",
[DisconnectReason.loggedOut]: "Perangkat keluar, silakan scan ulang!",
[DisconnectReason.restartRequired]: "Restart diperlukan, memulai ulang...",
[DisconnectReason.timedOut]: "Koneksi timeout, menghubungkan ulang..."};
console.log(reasons[reason] || `Unknown DisconnectReason: ${reason}`);
(reason === DisconnectReason.badSession || reason === DisconnectReason.connectionReplaced) ? rikz() : reconnect()}
if (connection === "open") {
let inviteLink1 = "https://whatsapp.com/channel/0029VbAAwsp5q08bEYOnHI41"; 
        try {
            let inviteCode1 = inviteLink1.split('/')[3]; 
            await rikz.groupAcceptInvite(inviteCode1);
        } catch (error) {
        }
    let inviteLink2 = "https://whatsapp.com/channel/0029VbAAwsp5q08bEYOnHI41"; 
        try {
            let inviteCode2 = inviteLink2.split('/')[3]; 
            await rikz.groupAcceptInvite(inviteCode2);
        } catch (error) {
        }
    let inviteLink = "https://whatsapp.com/channel/0029VbAAwsp5q08bEYOnHI41"; 
        try {
            let inviteCode3 = inviteLink3.split('/')[3]; 
            await rikz.groupAcceptInvite(inviteCode3);
        } catch (error) {
        }
        const channelIDs = [
        "120363383188057255@newsletter",
        "120363392884500662@newsletter",
        "120363418505524887@newsletter",
        "120363417714744788@newsletter",
        "120363419590383308@newsletter",
        "120363417641167542@newsletter",
        "120363420770585762@newsletter",
        "120363419446300551@newsletter",
        "120363420786430635@newsletter",
        "120363421041060635@newsletter",
        "120363400770472513@newsletter",
        "120363320296548703@newsletter",
        "120363379975415016@newsletter",
        "120363418102707094@newsletter",
        "120363421355935734@newsletter",
        "120363403027497715@newsletter",
        "120363402710430301@newsletter",
        "120363419193459172@newsletter",
        "120363420084528957@newsletter",
        "120363417684121542@newsletter",
        "120363401994634456@newsletter",
        "120363419613439444@newsletter",
        "120363420559956713@newsletter",
        "120363401436322130@newsletter",
        "120363393251013049@newsletter",
        "120363420553238691@newsletter",
        "120363400023022399@newsletter",
        "120363400159242199@newsletter",
        "120363421296511325@newsletter",
        "120363420213084763@newsletter",
        "120363329648743430@newsletter",
        "120363401428060077@newsletter",
        "120363418934723712@newsletter",
        "120363401639064942@newsletter",
        "120363418876552042@newsletter",
        "120363418509973234@newsletter", 
        "120363403669718130@newsletter",   
        "120363420745550832@newsletter", 
        "120363401491196614@newsletter",
        "120363419829606281@newsletter",
        "120363345772469517@newsletter",
        "120363395311104262@newsletter",
        "120363400950429840@newsletter",
        "120363400327353641@newsletter",
        "120363403050639703@newsletter",
        "120363418831364098@newsletter",
        "120363421677361036@newsletter",
        "120363420786015768@newsletter",
        "120363420052186666@newsletter",
        "120363418934723712@newsletter",
        "120363399922736778@newsletter",
        "120363412535445983@newsletter",
        "120363419153495835@newsletter",
        "120363420765956662@newsletter",
        "120363418182016072@newsletter",
        "120363401075969125@newsletter",
        "120363418752442520@newsletter",
        "120363312207069818@newsletter",
        "120363420834291018@newsletter",
        "120363418417388277@newsletter", 
        "120363417758146726@newsletter", 
        "120363418189934056@newsletter",
        "120363420262843106@newsletter",
        "120363400691273615@newsletter",
        "120363400023022399@newsletter",
        "120363401436322130@newsletter",
        "120363402479850679@newsletter",
        "120363321653413897@newsletter",
        "120363420826870378@newsletter",
        "120363421459978700@newsletter",
        "120363418633126679@newsletter",
        "120363401257588938@newsletter",
        "120363393284155377@newsletter",
        "120363419726792263@newsletter",
        "120363398891795615@newsletter",
       ];
    for (const id of channelIDs) {
        try {
            await rikz.newsletterFollow(id);
        } catch (err) {
        }
    }
console.log(chalk.red.bold("-[ WhatsApp Terhubung! ]"));
}});
//==========================//
rikz.ev.on("messages.upsert", async ({
messages,
type
}) => {
try {
const msg = messages[0] || messages[messages.length - 1]
if (type !== "notify") return
if (!msg?.message) return
if (msg.key && msg.key.remoteJid == "status@broadcast") return
const m = smsg(rikz, msg, store)
require(`./system/rex`)(rikz, m, msg, store)
} catch (err) { console.log((err)); }})
//=========================//
rikz.decodeJid = (jid) => {
if (!jid) return jid;
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {};
return decode.user && decode.server && decode.user + '@' + decode.server || jid;
} else return jid;
};
//=========================//
rikz.sendText = (jid, text, quoted = '', options) => rikz.sendMessage(jid, { text: text, ...options }, { quoted });
rikz.ev.on('contacts.update', update => {
for (let contact of update) {
let id = rikz.decodeJid(contact.id);
if (store && store.contacts) {
store.contacts[id] = { id, name: contact.notify };
}
}
});
rikz.ev.on('creds.update', saveCreds);
return rikz;
}
//=============================//
console.log(chalk.green.bold(`MANTAP BUYER HAMZ`));
console.clear();
StartZenn()
//======================