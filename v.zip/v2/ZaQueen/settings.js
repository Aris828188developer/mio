/*
Developer Info :
YT : https://Youtube.com/@YuukeyMiAyam
TT : https://tiktok.com/@yuukeyoffc
WA : wa.me/6285943212106
TELE : t.me/YuukeySikma
Jangan Hapus Wm Yah Sayangku, Kalo Mau Tambahin Nama Kalian Ajah
*/
const fs = require('fs')

//===[ SETTING BOT ]===\\
global.botname = "Killer Queen"// nama bot
global.version = "Season 1"// versi bot
global.owner = "601129601577"// nomor owner
global.footer = "Yuukey Sigma"// footer doank bebas ganti
global.idch = "" // id ch
global.packname = "Mi Ayam"// nama stiker pack
global.session = "session"// nama session

//Global Thumb
global.thumb = "https://pornhub"

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
