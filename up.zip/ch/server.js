const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*', // Adjust for production to your domain
    methods: ['GET', 'POST']
  }
});

let onlineCount = 0;

io.on('connection', (socket) => {
  onlineCount++;
  io.emit('onlineCount', onlineCount); // Broadcast to all clients
  console.log(`User connected. Online: ${onlineCount}`);

  socket.on('disconnect', () => {
    onlineCount = Math.max(0, onlineCount - 1);
    io.emit('onlineCount', onlineCount); // Broadcast updated count
    console.log(`User disconnected. Online: ${onlineCount}`);
  });
});

app.get('/', (req, res) => {
  res.send('Mio Komuniti Backend');
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});