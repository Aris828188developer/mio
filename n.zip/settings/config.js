global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['601129601577']
global.gambar = "https://files.catbox.moe/cut62d.jpg"
// GANTI NO OWNER DENGAN NOMOR MU LALU RUNN SEPERTI BIASA !!!